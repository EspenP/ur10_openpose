function CHECK(expr, error_msg)

if ~expr
  error(error_msg);
end

end
